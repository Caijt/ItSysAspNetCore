﻿using Microsoft.AspNetCore.Identity;

namespace Christ3D.Infrastruct.Identity.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
    }
}
