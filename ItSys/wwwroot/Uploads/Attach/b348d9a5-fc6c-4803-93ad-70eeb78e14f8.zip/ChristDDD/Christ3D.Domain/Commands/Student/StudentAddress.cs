﻿namespace Christ3D.Domain.Commands
{
    /// <summary>
    /// 地址
    /// </summary>
    public class StudentAddress
    {
        public string Province { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string Street { get; set; }



    }
}
